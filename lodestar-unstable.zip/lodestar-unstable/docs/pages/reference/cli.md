# Page relocated

_**Welcome! This page has been moved. Please checkout our new docs layout from the Table of Contents! Below are some helpful links to the CLI pages that were split out from this original document**_

- [Beacon Node CLI](../run/beacon-management/beacon-cli.md)
- [Validator CLI](../run/validator-management/validator-cli.md)
- [Bootnode CLI](../run/bootnode/bootnode-cli.md)
- [Light Client CLI](../libraries/lightclient-prover/lightclient-cli.md)
- [Dev CLI](../contribution/dev-cli.md)
