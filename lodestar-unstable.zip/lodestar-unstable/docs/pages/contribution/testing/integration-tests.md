# Integration Tests

The following tests are found in `packages/beacon-node`

#### `test:sim:mergemock`

#### `yarn test:sim:blobs`
