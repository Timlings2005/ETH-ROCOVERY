import {ArchiveMode} from "./interface.js";

export const DEFAULT_ARCHIVE_MODE = ArchiveMode.Frequency;

export const PROCESS_FINALIZED_CHECKPOINT_QUEUE_LENGTH = 256;
