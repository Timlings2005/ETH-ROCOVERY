export type DatabaseOptions = {
  name: string;
};

export const defaultDbOptions: DatabaseOptions = {
  name: "./.tmp/lodestar-db",
};
