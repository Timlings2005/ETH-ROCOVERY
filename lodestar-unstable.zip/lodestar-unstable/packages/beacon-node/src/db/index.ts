export type {IBeaconDb} from "./interface.js";
export {BeaconDb} from "./beacon.js";
