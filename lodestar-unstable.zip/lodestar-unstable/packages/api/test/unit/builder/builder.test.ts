import {createChainForkConfig, defaultChainConfig} from "@lodestar/config";
import {describe} from "vitest";
import {getClient} from "../../../src/builder/client.js";
import {Endpoints} from "../../../src/builder/routes.js";
import {getRoutes} from "../../../src/builder/server/index.js";
import {runGenericServerTest} from "../../utils/genericServerTest.js";
import {testData} from "./testData.js";

describe("builder", () => {
  runGenericServerTest<Endpoints>(
    createChainForkConfig({...defaultChainConfig, ELECTRA_FORK_EPOCH: 0}),
    getClient,
    getRoutes,
    testData
  );
});
